Jefferson Lam  
11-20-13  
JavaScript Assignment 1  

Assignment:  
1. Create a program that goes through each value in array x, where x is [3,5,'Dojo', 'rocks', {name: 'Michael', title: 'Sensei'}]. Have it display each value of the array as well as the type of each value. For example, it should say or log "3: 'number', 5: 'number', 'rocks': 'string', ...".  
2. Add a new value in the array x using a push method. New value you should add is 100.  
3. Add a new array as the last member of the array then log x in the console and analyze how x looks.  
4. Create a simple for loop that sums all the numbers between 1 to 500. Have console log the final sum.  
5. Create another simple for loop that sums all the numbers between 1 to 1 million. Now, we want you to figure out how long in milliseconds this operation takes. Study http://www.w3schools.com/jsref/jsref_gettime.asp to learn more about how you can get the time in milliseconds. You can basically get the time of the operation by getting this timestamp before you start the for loop and getting another timestamp after the for loop is over. By subtracting the two timestamps, you can obtain how long this operation took.